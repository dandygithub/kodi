import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

settings = xbmcaddon.Addon(id='script.module.translit')
version = "2.1.0"
plugin = "Translit-" + version
