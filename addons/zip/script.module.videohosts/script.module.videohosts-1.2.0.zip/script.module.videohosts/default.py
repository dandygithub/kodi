import xbmcaddon

settings = xbmcaddon.Addon(id='script.module.videohosts')
version = "1.1.0"
plugin = "VideoHosts-" + version
