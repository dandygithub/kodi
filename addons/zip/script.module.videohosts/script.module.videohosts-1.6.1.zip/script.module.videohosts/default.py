import xbmcaddon

settings = xbmcaddon.Addon(id='script.module.videohosts')
version = "1.4.0"
plugin = "VideoHosts-" + version
