import xbmcaddon

settings = xbmcaddon.Addon(id='script.module.videohosts')
version = "1.0.0"
plugin = "VideoHosts-" + version
