from . import sc_yohoho

def process(kp_id):
    list_li = []
    list_li += sc_yohoho.process(kp_id)     

    return list_li 
