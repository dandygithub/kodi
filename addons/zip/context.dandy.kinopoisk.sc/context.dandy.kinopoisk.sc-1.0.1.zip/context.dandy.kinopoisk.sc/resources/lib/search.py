import sc_noughth

def process(kp_id):
    return sc_noughth.process(kp_id)
