# -*- coding: utf-8 -*-

import plugin

plugin.run()
