__title__ = 'pytube'
__version__ = '0.1.16'
__author__ = 'Nick Ficano'
__license__ = 'MIT License'
__copyright__ = 'Copyright 2013 Nick Ficano'

from .api import YouTube
