import xbmc
import xbmcaddon

settings = xbmcaddon.Addon(id='script.module.favorites')
version = "2.1.0"
plugin = "Favorites-" + version
