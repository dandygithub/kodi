USER_AGENT = "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0"
PLAYLIST_DOMAIN = 's9.cdnapponline.com'
QUALITY_TYPES = (360, 480, 720, 1080, 2160)
PluginId = 'plugin.video.hdrezka.tv'