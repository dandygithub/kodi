import base64

BK_SEP = r'\/\/_\/\/'
BK_BLOCKS = [
    'JCQhIUAkJEBeIUAjJCRA',
    'QEBAQEAhIyMhXl5e',
    'IyMjI14hISMjIUBA',
    'Xl5eIUAjIyEhIyM=',
    'JCQjISFAIyFAIyM='
]


def parse_streams(salted):
    for bk in BK_BLOCKS:
        salted = salted.replace(BK_SEP + bk, '')
    return base64.b64decode(salted).decode('utf-8')
